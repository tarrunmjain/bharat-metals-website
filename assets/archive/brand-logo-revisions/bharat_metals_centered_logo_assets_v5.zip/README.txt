Bharat Metals centered logo asset pack v5

This version uses a clean red India map rebuilt from the user's original reference and places the BM circle at the visual center of the India map/mainland, not in a corner.

Assets:
- bharat-metals-bm-map-icon-centered-transparent.png
- bharat-metals-bm-map-icon-centered-transparent.webp
- bharat-metals-horizontal-logo-centered-transparent.png
- bharat-metals-horizontal-logo-centered-transparent.webp
- bharat-metals-header-logo-centered-transparent.png
- bharat-metals-header-logo-centered-transparent.webp

Use these directly. Do not let Codex redraw the logo from imagination.
